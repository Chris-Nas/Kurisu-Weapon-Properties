Hooks.on('ready', () => {
	CONFIG.DND5E.weaponProperties['armorpiercing'] = 'Armor Piercing';
  	CONFIG.DND5E.weaponProperties['blackpowder'] = 'Blackpowder';
	CONFIG.DND5E.weaponProperties['brutal'] = 'Brutal';
	CONFIG.DND5E.weaponProperties['cumbersome'] = 'Cumbersome';
	CONFIG.DND5E.weaponProperties['defending'] = 'Defending';
	CONFIG.DND5E.weaponProperties['disarming'] = 'Disarming';
	CONFIG.DND5E.weaponProperties['double'] = 'Double';
	CONFIG.DND5E.weaponProperties['entangling'] = 'Entangling';
	CONFIG.DND5E.weaponProperties['guard'] = 'Guard';
	CONFIG.DND5E.weaponProperties['hafted'] = 'Hafted';
	CONFIG.DND5E.weaponProperties['magazine'] = 'Magazine';
	CONFIG.DND5E.weaponProperties['momentum'] = 'Momentum';
	CONFIG.DND5E.weaponProperties['precise'] = 'Precise';
	CONFIG.DND5E.weaponProperties['repeater'] = 'Repeater';
	CONFIG.DND5E.weaponProperties['restraining'] = 'Restraining';
	CONFIG.DND5E.weaponProperties['returning'] = 'Returning';
	CONFIG.DND5E.weaponProperties['scatter'] = 'Scatter';
	CONFIG.DND5E.weaponProperties['set'] = 'Set';
	CONFIG.DND5E.weaponProperties['strongdraw'] = 'Strong-Draw';
	CONFIG.DND5E.weaponProperties['swift'] = 'Swift';
	CONFIG.DND5E.weaponProperties['tripping'] = 'Tripping';
	
});
